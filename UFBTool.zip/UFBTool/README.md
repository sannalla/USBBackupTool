1. Install the python libraries through the requirement.txt file
   ~ pip install -r requirements.txt 
3.	Create the app icon
   ~ python build.py
3.	Navigate to the dist folder and execute the gui installer and then pin to task bar
