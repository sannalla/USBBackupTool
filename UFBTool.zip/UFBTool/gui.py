# gui.py

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from file_encryption import encrypt_file_to_usb, decrypt_file_from_usb
from file_handler_module import encrypt_directory
from shutil import copytree
import psutil
import time
import os
import webbrowser
import sys

def open_help_page():
    if getattr(sys, 'frozen', False):
        help_file_path = os.path.join(sys._MEIPASS, 'resources', 'help.html')
    else:
        help_file_path = os.path.join(os.getcwd(), 'resources', 'help.html') 
    webbrowser.open(f'file://{help_file_path}') 

def select_usb_drive():
    usb_drives = detect_usb_drives()
    if not usb_drives:
        messagebox.showwarning("USB Drive", "No USB drives detected.")
        return None

    select_window = tk.Toplevel(root)
    select_window.title("Select USB Drive")

    label = tk.Label(select_window, text="Select a USB drive:")
    label.pack(pady=10)

    selected_drive = tk.StringVar(value=usb_drives[0])

    drive_menu = ttk.Combobox(select_window, textvariable=selected_drive, values=usb_drives, state="readonly")
    drive_menu.pack(pady=10)

    def confirm_selection():
        select_window.destroy()

    confirm_button = tk.Button(select_window, text="Confirm", command=confirm_selection)
    confirm_button.pack(pady=10)

    root.wait_window(select_window) 
    return selected_drive.get()

def encrypt_workflow():
    option = messagebox.askquestion("Encrypt", "Do you want to encrypt a directory instead of a single file?")

    if option == 'yes':
        directory_path = filedialog.askdirectory(title="Select a directory to encrypt")
        if not directory_path:
            messagebox.showwarning("Directory Selection", "No directory selected.")
            return
    else:
        file_path = filedialog.askopenfilename(title="Select a file to encrypt")
        if not file_path:
            messagebox.showwarning("File Selection", "No file selected.")
            return

    selected_drive = select_usb_drive()

    if not selected_drive:
        return

    progress_win = tk.Toplevel(root)
    progress_win.title("Encrypting...")
    progress_label = tk.Label(progress_win, text="Encrypting, please wait...")
    progress_label.pack(pady=10)

    progress_bar = ttk.Progressbar(progress_win, orient='horizontal', mode='determinate', length=300)
    progress_bar.pack(pady=20)
    progress_bar["maximum"] = 100 

    def perform_encryption():
        try:
            progress_bar["value"] = 20
            progress_win.update()
            time.sleep(1)

            progress_bar["value"] = 50
            progress_win.update()
            time.sleep(1)

            if option == 'yes':
                encrypt_directory(directory_path, selected_drive, encrypt_file_to_usb)
            else:
                encrypt_file_to_usb(file_path, selected_drive)

            progress_bar["value"] = 100
            progress_win.update()

            messagebox.showinfo("Success", "Encryption completed successfully!")

        except Exception as e:
            messagebox.showerror("Error", f"Error during encryption: {e}")   
        finally:
            progress_win.destroy()

    root.after(500, perform_encryption) 

def decrypt_workflow():
    encrypted_file = filedialog.askopenfilename(
        title="Select the encrypted file", 
        filetypes=[("Encrypted files", "*.enc")]
    )
    if not encrypted_file:
        messagebox.showwarning("File Selection", "No encrypted file selected.")
        return

    private_key_path = filedialog.askopenfilename(
        title="Select your RSA private key file", 
        filetypes=[("PEM files", "*.pem")]
    )
    if not private_key_path:
        messagebox.showwarning("Key Selection", "No private key selected.")
        return

    selected_drive = select_usb_drive()
    if not selected_drive:
        return
    
    file_types = [".txt", ".pdf", ".docx", ".xlsx", ".jpg", ".png"]
    extension_window = tk.Toplevel(root)
    extension_window.title("Select File Type")

    extension_label = tk.Label(extension_window, text="Select the file type for decryption:")
    extension_label.pack(pady=10)

    selected_extension = tk.StringVar(value=file_types[0])

    extension_menu = ttk.Combobox(extension_window, textvariable=selected_extension, values=file_types, state="readonly")
    extension_menu.pack(pady=10)

    def confirm_extension():
        extension_window.destroy()

    confirm_button = tk.Button(extension_window, text="Confirm", command=confirm_extension)
    confirm_button.pack(pady=10)

    root.wait_window(extension_window) 

    file_extension = selected_extension.get()

    progress_win = tk.Toplevel(root)
    progress_win.title("Decrypting...")
    progress_label = tk.Label(progress_win, text="Decrypting, please wait...")
    progress_label.pack(pady=10)

    progress_bar = ttk.Progressbar(progress_win, orient='horizontal', mode='determinate', length=300)
    progress_bar.pack(pady=20)
    progress_bar["maximum"] = 100

    def perform_decryption():
        try:
            progress_bar["value"] = 20
            progress_win.update()
            time.sleep(1)

            progress_bar["value"] = 50
            progress_win.update()
            time.sleep(1)

            decrypt_file_from_usb(encrypted_file, selected_drive, private_key_path, file_extension)

            progress_bar["value"] = 100
            progress_win.update()

            messagebox.showinfo("Success", "Decryption completed successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Error during decryption: {e}")
        finally:
            progress_win.destroy()

    root.after(500, perform_decryption)

def detect_usb_drives():
    usb_drives = []
    partitions = psutil.disk_partitions()

    for partition in partitions:
        if 'removable' in partition.opts:
            usb_drives.append(partition.device)

    return usb_drives

root = tk.Tk()
root.title("Encrypted USB File Backup Tool")
root.geometry("400x300")

title_label = tk.Label(root, text="Encrypted USB File Backup Tool", font=("Arial", 16))
title_label.pack(pady=20)

backup_button = tk.Button(root, text="Backup Files", width=20, height=2, command=encrypt_workflow)
backup_button.pack(pady=10)

restore_button = tk.Button(root, text="Restore Files", width=20, height=2, command=decrypt_workflow)
restore_button.pack(pady=10)

help_button = tk.Button(root, text="Learn More", width=20, height=2, command=open_help_page)
help_button.pack(pady=10)

root.mainloop()

