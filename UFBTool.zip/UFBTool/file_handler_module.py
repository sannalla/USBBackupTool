# file_handler_module.py

import os

SUPPORTED_FILE_TYPES = [".txt", ".pdf", ".docx", ".xlsx", ".zip"]

def get_supported_files(directory):
    supported_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if any(file.lower().endswith(ext) for ext in SUPPORTED_FILE_TYPES):
                supported_files.append(os.path.join(root, file))
    return supported_files

def process_files(files, process_function, *args):
    for file in files:
        try:
            print(f"Processing: {file}")
            process_function(file, *args)
        except Exception as e:
            print(f"Error processing file {file}: {e}")

def encrypt_directory(directory, usb_drive, encrypt_function):
    files = get_supported_files(directory)
    if not files:
        print("No supported files found in the directory.")
        return

    process_files(files, encrypt_function, usb_drive)

if __name__ == "__main__":
    print("This is a helper module for multi-file handling. Integrate it into your main application.")
