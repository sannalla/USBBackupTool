# file_encryption.py

import os
from aes_encryption import generate_aes_key, aes_encrypt_file, save_encrypted_file
from aes_encryption import aes_decrypt_file 
from rsa_encryption import generate_rsa_key_pair, get_public_key, save_private_key, save_public_key, rsa_encrypt_key, rsa_decrypt_key
from cryptography.hazmat.primitives import serialization

def encrypt_file_to_usb(file_path, usb_drive):
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    storage_folder = os.path.join(usb_drive, file_name)

    if not os.path.exists(storage_folder):
        os.mkdir(storage_folder)

    aes_key = generate_aes_key()

    iv, ciphertext, tag = aes_encrypt_file(file_path, aes_key)

    private_key = generate_rsa_key_pair()
    public_key = get_public_key(private_key)

    save_private_key(private_key, os.path.join(storage_folder, 'private_key.pem'))
    save_public_key(public_key, os.path.join(storage_folder, 'public_key.pem'))

    encrypted_aes_key = rsa_encrypt_key(aes_key, public_key)

    save_encrypted_file(os.path.join(storage_folder, file_name), iv, ciphertext, tag)

    with open(os.path.join(storage_folder, file_name + ".key.enc"), 'wb') as f:
        f.write(encrypted_aes_key)

    print(f"File '{file_path}' has been encrypted and stored in the folder '{storage_folder}'!")

def decrypt_file_from_usb(file_path, usb_drive, private_key_path, file_extension):
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    storage_folder = os.path.join(usb_drive, file_name)

    try:
        with open(os.path.join(storage_folder, file_name + ".key.enc"), 'rb') as f:
             encrypted_aes_key = f.read()
    except FileNotFoundError:
        print(f"Error: Encrypted AES key file not found in {storage_folder}")
        return
    
    try:
        with open(private_key_path, 'rb') as f:
            private_key = serialization.load_pem_private_key(f.read(), password=None)
    except FileNotFoundError:
        print(f"Error: The private key file at '{private_key_path}' was not found.")
        return
    
    aes_key = rsa_decrypt_key(encrypted_aes_key, private_key)

    iv, ciphertext, tag = None, None, None
    encrypted_file_path = os.path.join(storage_folder, file_name + ".enc")
    
    try:
        with open(encrypted_file_path, 'rb') as encrypted_file:
            iv = encrypted_file.read(12)  
            ciphertext_and_tag = encrypted_file.read() 
            ciphertext = ciphertext_and_tag[:-16] 
            tag = ciphertext_and_tag[-16:] 
    except FileNotFoundError:
        print(f"Error: Encrypted file not found at {encrypted_file_path}")
        return

    try:
        decrypted_content = aes_decrypt_file(iv, ciphertext, tag, aes_key)

        decrypted_file_path = file_path.replace(".enc", "_decrypted") + file_extension
        with open(decrypted_file_path, 'wb') as decrypted_file:
            decrypted_file.write(decrypted_content)

        print(f"File '{file_path}' has been decrypted successfully as '{decrypted_file_path}'!")
    except Exception as e:
        print(f"Error during AES decryption: {e}")