# aes_encryption.py

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import os

def generate_aes_key(key_size=32):
    return os.urandom(key_size)

def aes_encrypt_file(file_path, key):
    with open(file_path, 'rb') as file:
        plaintext = file.read()

    iv = os.urandom(12)

    encryptor = Cipher(
        algorithms.AES(key),
        modes.GCM(iv),
        backend=default_backend()
    ).encryptor()

    ciphertext = encryptor.update(plaintext) + encryptor.finalize()

    return iv, ciphertext, encryptor.tag

def save_encrypted_file(file_path, iv, ciphertext, tag):
    file_extension = os.path.splitext(file_path)[1]
    with open(file_path + f"{file_extension}.enc", 'wb') as file:
        file.write(iv + ciphertext + tag)

def aes_decrypt_file(iv, ciphertext, tag, key):
    decryptor = Cipher(
        algorithms.AES(key),
        modes.GCM(iv, tag),
        backend=default_backend()
    ).decryptor()

    decrypted_content = decryptor.update(ciphertext) + decryptor.finalize()
    
    return decrypted_content