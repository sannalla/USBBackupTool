# build.py

import subprocess
import os

def build_executable():
    script_path = os.path.join(os.getcwd(), 'gui.py') 
    icon_path = os.path.join(os.getcwd(), 'resources', 'eufb_tool.ico')
    help_file_path = os.path.join('resources', 'help.html')
    images_path = os.path.join('resources', 'images')

    pyinstaller_command = [
        'pyinstaller',
        '--onefile',
        '--windowed',
        f'--icon={icon_path}',
        f'--add-data={help_file_path};resources',
        f'--add-data={images_path};resources/images',
        script_path
    ]

    subprocess.run(pyinstaller_command)

if __name__ == '__main__':
    build_executable()
    print("Executable built successfully.")
