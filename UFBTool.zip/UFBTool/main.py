# main.py 

from file_encryption import encrypt_file_to_usb, decrypt_file_from_usb
from file_handler_module import encrypt_directory
from psutil import disk_partitions

def detect_usb_drives():
    usb_drives = []
    partitions = disk_partitions()

    for partition in partitions:
        if 'removable' in partition.opts:
            usb_drives.append(partition.device)

    if not usb_drives:
        print("No USB drives detected.")
    else:
        print("Detected USB drives:", usb_drives)

    return usb_drives

if __name__ == "__main__":
    action = input("Would you like to (E)ncrypt or (D)ecrypt a file? ").strip().lower()
    mode = input("Do you want to process a single file or a directory? (F)ile/(D)irectory: ").strip().lower()

    usb_drives = detect_usb_drives()

    if not usb_drives:
        print("No USB drives found. Please connect a USB drive.")
        exit()

    selected_drive = usb_drives[0]

    if mode == 'f':
        file_path = input("Enter the path to the file: ").strip()

        if action == 'e':
            encrypt_file_to_usb(file_path, selected_drive)
        elif action == 'd':
            private_key_path = input("Enter the path to the private key: ").strip()
            decrypt_file_from_usb(file_path, selected_drive, private_key_path)
        else:
            print("Invalid option. Please choose 'E' to encrypt or 'D' to decrypt.")

    elif mode == 'd':
        directory_path = input("Enter the path to the directory: ").strip()

        if action == 'e':
            encrypt_directory(directory_path, selected_drive, encrypt_file_to_usb)
        else:
            print("Invalid option. Directory decryption is not supported. Please choose 'E' to encrypt.")

    else:
        print("Invalid mode. Please choose 'F' for file or 'D' for directory.")
